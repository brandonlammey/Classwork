
public class Ex2 
{
	public static void main(String args[])
	{	
		System.out.println("My name is Brandon Lammey.");
		System.out.println("I am majoring in computer science.");
		System.out.println("My hobbys are:");
		System.out.println("\t Screaming silently in public spaces");
		System.out.println("\t Cartwheeling by the river");
		System.out.println("\t Eating books");
		System.out.println("\t Pretending to work at Target");
		System.out.println("Stay Classy");
	}
}
